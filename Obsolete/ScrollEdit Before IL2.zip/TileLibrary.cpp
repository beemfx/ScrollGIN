#include "tilelibrary.h"

/*
	You may notice a series of subtract 1's around that is becuase the reference
	is measured starting from one not zero so to get the correct element from the
	various arrays it is neccesary to subtract 1.
*/

CTileLibrary::CTileLibrary(){
	
}

CTileLibrary::~CTileLibrary(){
	SAFE_DELETE_ARRAY(m_pTileData);
	CloseMainBitmap();
}


HRESULT CTileLibrary::ClearDataBase(){
	for(int i=0;i<m_nNumEntries;i++){
		ZeroMemory(&m_pTileData[i], sizeof(STileData));
		m_nNumEntries=0;
		m_nSelectedEntry=1;
	}
	return S_OK;
}


USHORT CTileLibrary::GetNumEntries(){
	return m_nNumEntries;
}


USHORT CTileLibrary::GetSelectedEntry(){
	return m_nSelectedEntry;
}

void CTileLibrary::SetSelectedEntry(int newentryvalue){
	if(newentryvalue<1)m_nSelectedEntry=m_nNumEntries;
	else if(newentryvalue>m_nNumEntries)m_nSelectedEntry=1;
	else m_nSelectedEntry=newentryvalue;
}



//A modified version of this file will allow some major
//allowance of zip type files.
HRESULT CTileLibrary::OpenBitmap2(LPTSTR BitmapFilename, DWORD OffsetBytes){
	HANDLE hFile;
	BITMAPFILEHEADER bmfh;
	BITMAPINFO *pbmi;
	BYTE *pBits;
	DWORD dwBytesRead;
	BOOL bSuccess;
	DWORD dwInfoSize;

	hFile=CreateFile(BitmapFilename, GENERIC_READ, FILE_SHARE_READ, NULL,
							OPEN_EXISTING, 0, NULL);

	if(hFile==INVALID_HANDLE_VALUE)return E_FAIL;

	SetFilePointer(hFile, OffsetBytes, NULL, FILE_BEGIN);
	bSuccess=ReadFile(hFile, &bmfh, sizeof(BITMAPFILEHEADER), &dwBytesRead, NULL);

	if(!bSuccess || (dwBytesRead != sizeof(BITMAPFILEHEADER))
					|| (bmfh.bfType != * (WORD *) "BM"))
	{
		CloseHandle(hFile);
		return E_FAIL;
	}

	dwInfoSize=bmfh.bfOffBits - sizeof(BITMAPFILEHEADER);
	pbmi = new BITMAPINFO[dwInfoSize];//malloc(dwInfoSize);
	bSuccess=ReadFile(hFile, pbmi, dwInfoSize, &dwBytesRead, NULL);
	if(!bSuccess ||(dwBytesRead != dwInfoSize))
	{
		SAFE_DELETE_ARRAY(pbmi);
		CloseHandle(hFile);
		return E_FAIL;
	}

	m_hMainBitmap=CreateDIBSection(NULL, pbmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	if(m_hMainBitmap==NULL)
	{
		SAFE_DELETE_ARRAY(pbmi);
		CloseHandle(hFile);
		return E_FAIL;
	}

	ReadFile(hFile, pBits, bmfh.bfSize-bmfh.bfOffBits, &dwBytesRead, NULL);

	SAFE_DELETE_ARRAY(pbmi);
	//SAFE_DELETE_ARRAY(pBits);
	CloseHandle(hFile);
	
	_tcscpy(m_lpstrBitmapFilename, BitmapFilename);
	return S_OK;
}

HRESULT CTileLibrary::OpenBitmap(LPTSTR BitmapFilename){
	//make sure main bitmap is empty

	if(m_hMainBitmap){DeleteObject(m_hMainBitmap);m_hMainBitmap=NULL;}
	
	m_hMainBitmap=(HBITMAP)LoadImage(NULL, BitmapFilename,IMAGE_BITMAP, 
												NULL, NULL, LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if(m_hMainBitmap==NULL)return E_FAIL;
	
	_tcscpy(m_lpstrBitmapFilename, BitmapFilename);
	return S_OK;
}




/*
HRESULT CTileLibrary::CreateBitmapsFromData(){
	for(int i=1; i<=m_nNumEntries; i++){
		if(!CreateBitmapImage(i, m_pTileData[i].nX, m_pTileData[i].nY,
									m_pTileData[i].nWidth, m_pTileData[i].nHeight))return E_FAIL;
	}
	return S_OK;
}*/


/*
void CTileLibrary::CloseAllBitmaps(){
	for(int i=0;i<m_nMaxEntries;i++){
		if(m_pBitmaps[i])DeleteObject(m_pBitmaps[i]);
	}
}
*/

void CTileLibrary::CloseMainBitmap(){
	if(m_hMainBitmap){DeleteObject(m_hMainBitmap);m_hMainBitmap=NULL;}
}

HRESULT CTileLibrary::DisplayImage(HDC *hDc, int reference, int x, int y, BOOL bTransp){
	HDC hdcMainBitmap;

	if(reference<1||reference>m_nNumEntries)return S_FALSE;

	hdcMainBitmap=CreateCompatibleDC(*hDc);
	SelectObject(hdcMainBitmap, m_hMainBitmap);
	if(!bTransp){
		StretchBlt(*hDc, x, y, 40, 40, hdcMainBitmap, m_pTileData[reference-1].nX,
					m_pTileData[reference-1].nY, m_pTileData[reference-1].nWidth, 
					m_pTileData[reference-1].nHeight, SRCCOPY);
	
	}else{	
		HBITMAP hTileBitmap;
		HDC hdcTileBitmap;

		//Create an hdc and put the chosen bitmap in it
		hdcTileBitmap=CreateCompatibleDC(*hDc);
		hTileBitmap=CreateCompatibleBitmap(*hDc, 40, 40);
		SelectObject(hdcTileBitmap, hTileBitmap);

		StretchBlt(hdcTileBitmap, 0, 0, 40, 40, hdcMainBitmap, m_pTileData[reference-1].nX,
						m_pTileData[reference-1].nY, m_pTileData[reference-1].nWidth, m_pTileData[reference-1].nWidth,
						SRCCOPY);
		//We now have the 40x40 image in hdcTileBitmap
		
		//I'm not exactly sure how the following code works, I genereated
		//it by modifying some code found int eh MS knowledge base
		HBITMAP bmAndBack, bmAndObject, bmAndMem;//, bmSave;
		HDC hdcMem, hdcBack, hdcObject, hdcTemp;//, hdcSave;
		COLORREF cColor;

		//Create compatible DC's
		hdcMem=CreateCompatibleDC(*hDc);
		hdcBack=CreateCompatibleDC(*hDc);
		hdcObject=CreateCompatibleDC(*hDc);
		hdcTemp=CreateCompatibleDC(*hDc);


		//Monochrome bitmaps
		bmAndBack=CreateBitmap(40, 40, 1, 1, NULL);
		bmAndObject=CreateBitmap(40, 40, 1, 1, NULL);
		
		//Bitmaps
		bmAndMem=CreateCompatibleBitmap(*hDc, 40, 40);

		//Select bitmaps int DC's.
		SelectObject(hdcBack, bmAndBack);
		SelectObject(hdcObject, bmAndObject);
		SelectObject(hdcMem, bmAndMem);

		//Set map mode
		SetMapMode(hdcMem, GetMapMode(*hDc));
		
		//Set bacground color to desired value and save old value
		cColor=SetBkColor(hdcTileBitmap, RGB(255, 0, 255));

		//BitBlt monocrhrom version of image, transparent as white
		BitBlt(hdcObject, 0, 0, 40, 40, hdcTileBitmap, 0, 0, SRCCOPY);

		//Restore background color
		SetBkColor(hdcTileBitmap, cColor);

		//Create inverse of monochrome image
		BitBlt(hdcBack, 0, 0, 40, 40, hdcObject, 0, 0, NOTSRCCOPY);

		//Get copy of dest image
		BitBlt(hdcMem, 0, 0, 40, 40, *hDc, x, y, SRCCOPY);

		//Blt bw version to dest
		BitBlt(hdcMem, 0, 0, 40, 40, hdcObject, 0, 0, SRCAND);

		//blt inverted src to image
		BitBlt(hdcTileBitmap, 0, 0, 40, 40, hdcBack, 0, 0, SRCAND);

		//Blt main image to dest
		BitBlt(hdcMem, 0, 0, 40, 40, hdcTileBitmap, 0, 0, SRCPAINT);
		
		//Blt to screen
		BitBlt(*hDc, x, y, 40, 40, hdcMem, 0, 0, SRCCOPY);
		
		//Delete unused variables
		DeleteDC(hdcTileBitmap);
		DeleteDC(hdcMem);
		DeleteDC(hdcBack);
		DeleteDC(hdcObject);
		DeleteDC(hdcTemp);
		
		DeleteObject(bmAndBack);
		DeleteObject(bmAndObject);
		DeleteObject(bmAndMem);
		DeleteObject(hTileBitmap);
	}
	
	
	DeleteDC(hdcMainBitmap);

	return S_OK;
}