#include "ConstLibrary.h"

//If transparency is defined, architecture will be blitted with
//translucency.  However the program will only be compatible with
//Windows 98 and higher, or Windows 2000 and higher

#define TRANSPARENCY
#ifdef TRANSPARENCY
#pragma comment(lib, "msimg32.lib")
#endif //transparecty


CConstantLibrary::CConstantLibrary(LPCTSTR szBitmapName, int nNumEntries){
	m_nNumEntries=nNumEntries;
	m_pTileData=new STileData[nNumEntries];
	m_hMainBitmap=NULL;
	m_nSelectedEntry=1;

	m_hMainBitmap=(HBITMAP)LoadImage(GetModuleHandle(NULL), szBitmapName, IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR);
	for(int i=0; i<10; i++){
		m_pTileData[i].nHeight=40;
		m_pTileData[i].nWidth=40;
		m_pTileData[i].nX=i*40;
		m_pTileData[i].nY=0;
	}
	for(i=0; i<9; i++){
		m_pTileData[i+10].nHeight=40;
		m_pTileData[i+10].nWidth=40;
		m_pTileData[i+10].nX=i*40;
		m_pTileData[i+10].nY=40;
	}
	for(i=0; i<9; i++){
		m_pTileData[i+10+9].nHeight=40;
		m_pTileData[i+10+9].nWidth=40;
		m_pTileData[i+10+9].nX=i*40;
		m_pTileData[i+10+9].nY=80;
	}
}

CConstantLibrary::~CConstantLibrary(){
	
}

HRESULT CConstantLibrary::DisplayImage(HDC *hDc, int reference, int x, int y, BOOL bTransp){
	HDC hdcMainBitmap;
	
	if(reference<1||reference>m_nNumEntries)return S_FALSE;

	hdcMainBitmap=CreateCompatibleDC(*hDc);
	SelectObject(hdcMainBitmap, m_hMainBitmap);

	
	if(!bTransp){
		StretchBlt(*hDc, x, y, 40, 40, hdcMainBitmap, 
					m_pTileData[reference-1].nX,
					m_pTileData[reference-1].nY, 
					m_pTileData[reference-1].nWidth, 
					m_pTileData[reference-1].nHeight, SRCCOPY);
	
	}else{		
		#ifdef TRANSPARENCY
		//Lets alpha blend
		BLENDFUNCTION bf;
		bf.BlendOp=AC_SRC_OVER;
		bf.AlphaFormat=0;
		bf.BlendFlags=0;
		bf.SourceConstantAlpha=100;

		AlphaBlend(*hDc, x, y, 40, 40, hdcMainBitmap,
						m_pTileData[reference-1].nX,
						m_pTileData[reference-1].nY,
						m_pTileData[reference-1].nWidth,
						m_pTileData[reference-1].nHeight,
						bf);
		
		#else //TRANSPAREnCY

		HBITMAP hTileBitmap;
		HDC hdcTileBitmap;

		//Create an hdc and put the chosen bitmap in it
		hdcTileBitmap=CreateCompatibleDC(*hDc);
		hTileBitmap=CreateCompatibleBitmap(*hDc, 40, 40);
		SelectObject(hdcTileBitmap, hTileBitmap);

		StretchBlt(hdcTileBitmap, 0, 0, 40, 40, hdcMainBitmap, 
						m_pTileData[reference-1].nX,
						m_pTileData[reference-1].nY, 
						m_pTileData[reference-1].nWidth, 
						m_pTileData[reference-1].nWidth,
						SRCCOPY);
		//We now have the 40x40 image in hdcTileBitmap
		
		//I'm not exactly sure how the following code works, I genereated
		//it by modifying some code found int eh MS knowledge base
		HBITMAP bmAndBack, bmAndObject, bmAndMem;//, bmSave;
		HDC hdcMem, hdcBack, hdcObject, hdcTemp;//, hdcSave;
		COLORREF cColor;

		//Create compatible DC's
		hdcMem=CreateCompatibleDC(*hDc);
		hdcBack=CreateCompatibleDC(*hDc);
		hdcObject=CreateCompatibleDC(*hDc);
		hdcTemp=CreateCompatibleDC(*hDc);


		//Monochrome bitmaps
		bmAndBack=CreateBitmap(40, 40, 1, 1, NULL);
		bmAndObject=CreateBitmap(40, 40, 1, 1, NULL);
		
		//Bitmaps
		bmAndMem=CreateCompatibleBitmap(*hDc, 40, 40);

		//Select bitmaps int DC's.
		SelectObject(hdcBack, bmAndBack);
		SelectObject(hdcObject, bmAndObject);
		SelectObject(hdcMem, bmAndMem);

		//Set map mode
		SetMapMode(hdcMem, GetMapMode(*hDc));
		
		//Set bacground color to desired value and save old value
		cColor=SetBkColor(hdcTileBitmap, RGB(255, 255, 255));

		//BitBlt monocrhrom version of image, transparent as white
		BitBlt(hdcObject, 0, 0, 40, 40, hdcTileBitmap, 0, 0, SRCCOPY);

		//Restore background color
		SetBkColor(hdcTileBitmap, cColor);

		//Create inverse of monochrome image
		BitBlt(hdcBack, 0, 0, 40, 40, hdcObject, 0, 0, NOTSRCCOPY);

		//Get copy of dest image
		BitBlt(hdcMem, 0, 0, 40, 40, *hDc, x, y, SRCCOPY);

		//Blt bw version to dest
		BitBlt(hdcMem, 0, 0, 40, 40, hdcObject, 0, 0, SRCAND);

		//blt inverted src to image
		BitBlt(hdcTileBitmap, 0, 0, 40, 40, hdcBack, 0, 0, SRCAND);

		//Blt main image to dest
		BitBlt(hdcMem, 0, 0, 40, 40, hdcTileBitmap, 0, 0, SRCPAINT);
		
		//Blt to screen
		BitBlt(*hDc, x, y, 40, 40, hdcMem, 0, 0, SRCCOPY);
		
		//Delete unused variables
		DeleteDC(hdcTileBitmap);
		DeleteDC(hdcMem);
		DeleteDC(hdcBack);
		DeleteDC(hdcObject);
		DeleteDC(hdcTemp);
		
		DeleteObject(bmAndBack);
		DeleteObject(bmAndObject);
		DeleteObject(bmAndMem);
		DeleteObject(hTileBitmap);

		#endif //TRANSPARENCY
		
	}
	
	
	DeleteDC(hdcMainBitmap);

	return S_OK;
}
