#ifndef __CONSTLIBRARY_H__
#define __CONSTLIBRARY_H__

#include "TileLibrary.h"

class CConstantLibrary: public CTileLibrary{
private:
public:
	CConstantLibrary(LPCTSTR, int);
	~CConstantLibrary();
	HRESULT DisplayImage(HDC *hDc, int reference, int x, int y, BOOL bTransp);
};

#endif //__constlibrary_h__