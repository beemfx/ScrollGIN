//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDR_MAINMENU                    101
#define IDR_ACCELERATOR                 102
#define IDI_ICONMAIN                    105
#define IDB_ARCHTILES                   106
#define IDD_NEWDIALOG                   107
#define IDD_MAPSTATS                    108
#define IDD_MAPDIMS                     109
#define IDD_CHANGEFILENAME              110
#define IDD_ABOUTDLG                    111
#define IDC_MAPWIDTH                    1004
#define IDC_MAPHEIGHT                   1005
#define ID_CANCEL                       1006
#define ID_OK                           1007
#define IDC_LIBRARY                     1008
#define IDC_BACKGROUND                  1009
#define IDAPPLY                         1010
#define IDC_NEWWIDTH                    1011
#define IDC_NEWHEIGHT                   1012
#define IDC_VERSION                     1019
#define IDC_LIBRARYNAME                 1021
#define IDC_NEWFILENAME                 1022
#define IDC_BGFILENAME                  1023
#define ID_FILENEW                      40002
#define ID_FILEOPEN                     40003
#define ID_FILESAVE                     40004
#define ID_FILESAVEAS                   40005
#define ID_FILEEXIT                     40006
#define ID_LAYERTILE                    40007
#define ID_LAYERARCH                    40008
#define ID_LAYEROBJECT                  40009
#define ID_VIEWSHOWGRID                 40010
#define ID_EDITMAPDIM                   40011
#define ID_EDITBG                       40012
#define ID_EDITLIBRARY                  40013
#define ID_EDITSTATS                    40014
#define ID_HELPABOUT                    40015
#define ID_VIEWUSETRANSPARENT           40016
#define ID_HELPTOPICS                   40017
#define ID_LAYERCLEARLAYER              40018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40019
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
