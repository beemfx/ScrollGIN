/*
	EditMapBoard Class - A derived class for editing ScrollGIN maps.

	Coyright (c) 2002, Blaine Myers
*/

#ifndef __EDITMAPBOARD_H__
#define __EDITMAPBOARD_H__
#include "Mapboard.h"

class CEditMapBoard: public CMapBoard{
private:
public:
	HRESULT ClearArch();
	HRESULT ClearTile();
	HRESULT ClearObject();
	HRESULT SetTile(int x, int y, BYTE nNewValue); //Set value of tile at x,y
	HRESULT SetArch(int x, int y, BYTE nNewValue);  //Set value of architecture at x,y
	HRESULT SetArchSmart(int x, int y, BYTE nNewValue); //automatically sets arch using 0 as base
	HRESULT SetObject(int x, int y, BYTE nNewValue); //Set value of object at x,y

	BYTE GetArchSmart(int x, int y);
	
	HRESULT SaveMap(LPTSTR lpMapFilename); //Save the map to disk
	HRESULT GenerateNewMap(int nWidth, int nHeight, LPTSTR lpLibFilename, LPTSTR lpBGFilename); //Start a new map with chosen width, height, and library

	HRESULT ChangeMapDimensions(int nNewWidth, int nNewHeight); //Changes the map dimensions, preserving tile, arch, and object data
	void ChangeBackground(LPCTSTR lpBackgroundFilename); //Change the current background
	void ChangeLibrary(LPCTSTR lpLibraryFilename);
};

#endif //__editmapboard_h__