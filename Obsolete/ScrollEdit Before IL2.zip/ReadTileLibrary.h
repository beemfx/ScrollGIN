#ifndef __READTILELIBRARY_H__
#define __READTILELIBRARY_H__

#include "TileLibrary.h"

class CReadTileLibrary: public CTileLibrary{
private:
public:
	CReadTileLibrary(int maxtiles);
	~CReadTileLibrary();

	HRESULT LoadImageLib(LPCTSTR lpLibraryFilename);
};
#endif //__READTILELIBRARY_H__