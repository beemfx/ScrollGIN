#include "ReadTileLibrary.h"

CReadTileLibrary::CReadTileLibrary(int maxtiles){
	m_nNumEntries		=	0;
	m_pTileData			=	new STileData[maxtiles];
	m_hMainBitmap		=	NULL;
	m_nSelectedEntry	=	1;
}

CReadTileLibrary::~CReadTileLibrary(){

}

HRESULT CReadTileLibrary::LoadImageLib(LPCTSTR lpLibraryFilename){
	SLibraryHeader sLibraryHeader;
	SDataHeader2 sDataHeader2;
	
	HANDLE hFile;

	hFile=CreateFile(lpLibraryFilename, GENERIC_READ, FILE_SHARE_READ,
					(LPSECURITY_ATTRIBUTES)NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,
					(HANDLE)NULL);
	if(hFile==INVALID_HANDLE_VALUE)return E_FAIL;

	DWORD dwBytesRead;
	
	ReadFile(hFile, &sLibraryHeader, sizeof(SLibraryHeader), &dwBytesRead, NULL);
	if(sLibraryHeader.cType != *(WORD*)"IL"){CloseHandle(hFile); return E_FAIL;}
	if(sLibraryHeader.nVersion !=2){CloseHandle(hFile); return E_FAIL;}
	
	ReadFile(hFile, &sDataHeader2, sizeof(SDataHeader2), &dwBytesRead, NULL);
	
	ClearDataBase();

	ReadFile(hFile, m_pTileData, sDataHeader2.nSizeofEntryData, &dwBytesRead, NULL);

	m_nNumEntries=sDataHeader2.nEntrys;
	
	CloseHandle(hFile);

	if(SUCCEEDED(OpenBitmap2((LPTSTR)lpLibraryFilename, sDataHeader2.lBitmapOffset)))
		return S_OK;
	else return E_FAIL;
}