#include "EditTileLibrary.h"

CEditTileLibrary::CEditTileLibrary(int maxtiles=256){
	//int maxtiles=256;
	m_nMaxEntries=maxtiles;
	m_nNumEntries		=	0;
	m_pTileData			=	new STileData[maxtiles];
	m_hMainBitmap		=	NULL;
	m_nSelectedEntry	=	1;
}

CEditTileLibrary::~CEditTileLibrary(){

}

void CEditTileLibrary::GetBitmapName(LPTSTR dest){
	_tcscpy(dest, m_lpstrBitmapFilename);
}

BOOL CEditTileLibrary::AddEntry(int x, int y, int width, int height){
	if(m_nNumEntries==m_nMaxEntries)return FALSE;
	//increase the number of entries.
	m_nNumEntries++;
	if(CreateBitmapImage(m_nNumEntries, x, y, width, height))return TRUE;
	else return FALSE;

}

BOOL CEditTileLibrary::CreateBitmapImage(int reference, int x, int y, int width, int height){

	
	m_pTileData[reference-1].nX=x;
	m_pTileData[reference-1].nY=y;
	m_pTileData[reference-1].nWidth=width;
	m_pTileData[reference-1].nHeight=height;

	return TRUE;
}

//Auto determine data successfully generates tile data from an
//image
HRESULT CEditTileLibrary::AutoDetermineData(){
	//bail if main bitmap does not exist
	if(!m_hMainBitmap)return E_FAIL;

	int iNumAcross;
	int iNumDown;
	int iNumTiles;
	int iReference;

	BITMAP bm;
	GetObject(m_hMainBitmap, sizeof(bm), &bm);
	
	//get how many bitmaps across as well as how many down
	iNumAcross=bm.bmWidth/TILEDIMENSION;
	iNumDown=bm.bmHeight/TILEDIMENSION;
	iNumTiles=iNumAcross*iNumDown;
	iReference=1;
	for(int down=0;down<iNumDown;down++){
		for(int across=0;across<iNumAcross;across++, iReference++){
			m_pTileData[iReference-1].nX=across*TILEDIMENSION;
			m_pTileData[iReference-1].nY=down*TILEDIMENSION;
			m_pTileData[iReference-1].nWidth=TILEDIMENSION;
			m_pTileData[iReference-1].nHeight=TILEDIMENSION;
			m_nNumEntries++;
		}
	}
	return S_OK;
}

//Saves data to specified filename
BOOL CEditTileLibrary::SaveData(LPTSTR SaveFilename){
	//Start by opening the file
	HANDLE hSaveFile;
	DWORD  dwBytesWritten;
	if((hSaveFile=CreateFile(SaveFilename, GENERIC_WRITE, FILE_SHARE_WRITE, (LPSECURITY_ATTRIBUTES)NULL,
								CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, (HANDLE)NULL))==INVALID_HANDLE_VALUE)return FALSE;
	//Lets Genreate the headers
	SLibraryHeader sLibraryHeader;
	SDataHeader		sDataHeader;

	sLibraryHeader.cType=*(WORD*)"IL";
	//sLibraryHeader.cType[0]='I';sLibraryHeader.cType[1]='L';
	sLibraryHeader.nVersion=1;
	sLibraryHeader.lReserved1=0;
	sLibraryHeader.lReserved2=0;
	sLibraryHeader.nOffsetBits=sizeof(sLibraryHeader);

	//Write the file header
	WriteFile(hSaveFile, &sLibraryHeader, sLibraryHeader.nOffsetBits, &dwBytesWritten, NULL);

	//setup data header
	sDataHeader.nEntries=GetNumEntries();
	sDataHeader.nSizeofBitmapFilenameData=(_tcslen(m_lpstrBitmapFilename)+1)*sizeof(WCHAR);
	sDataHeader.nSizeofEntryData=sizeof(STileData)*sDataHeader.nEntries;
	
	//write library header
	WriteFile(hSaveFile, &sDataHeader, sizeof(sDataHeader), &dwBytesWritten, NULL);

	//Lets write the filename
	#ifdef UNICODE
	WriteFile(hSaveFile, m_lpstrBitmapFilename, sDataHeader.nSizeofBitmapFilenameData, &dwBytesWritten, NULL);
	#else //UNICODE NOT DEFIEND
	//Convert value to wide character and write to file
	WCHAR szTempBitmapName[MAX_PATH];
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, m_lpstrBitmapFilename, -1, szTempBitmapName, MAX_PATH);
	WriteFile(hSaveFile, szTempBitmapName, sDataHeader.nSizeofBitmapFilenameData, &dwBytesWritten, NULL);
	#endif
	//Lets write teh data
	WriteFile(hSaveFile, m_pTileData, sDataHeader.nSizeofEntryData, &dwBytesWritten, NULL); 

	CloseHandle(hSaveFile);
	return TRUE;
}

//clears current entry data and loads
//data from file
BOOL CEditTileLibrary::LoadData(LPTSTR LoadFilename){
	HANDLE hOpenFile;
	DWORD dwBytesRead;
	if((hOpenFile=CreateFile(LoadFilename, GENERIC_READ, FILE_SHARE_READ, (LPSECURITY_ATTRIBUTES)NULL,
									OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, (HANDLE)NULL))==INVALID_HANDLE_VALUE)return FALSE;
	//Lets Prepare to read the data
	SLibraryHeader sLibraryHeader;
	SDataHeader		sDataHeader;
	ZeroMemory(&sLibraryHeader, sizeof(sLibraryHeader));
	ZeroMemory(&sDataHeader, sizeof(sDataHeader));
	
	ReadFile(hOpenFile, &sLibraryHeader, sizeof(sLibraryHeader), &dwBytesRead, NULL);
	//MessageBox(NULL, "Made it here", "note", MB_OK);
	
	//the following code isn't working
	if(sLibraryHeader.cType!=*(WORD*)"IL"){
		CloseHandle(hOpenFile);
		return FALSE;
	}
	if(sLibraryHeader.nVersion!=1){
		CloseHandle(hOpenFile);
		return FALSE; //not a lib database probably an actual lib
	}
	SetFilePointer(hOpenFile, sLibraryHeader.nOffsetBits, NULL, FILE_BEGIN);
	

	//read image header
	ReadFile(hOpenFile, &sDataHeader, sizeof(sDataHeader), &dwBytesRead, NULL);
	
	//If teh file was written correctly it should work out so lets clear teh current data
	CloseMainBitmap();
	m_nSelectedEntry=1;
	m_nNumEntries=sDataHeader.nEntries;

	m_lpstrBitmapFilename[0]=NULL;
	//Lets Get the bitmap filesname
	#ifdef UNICODE 
	ReadFile(hOpenFile, m_lpstrBitmapFilename, sDataHeader.nSizeofBitmapFilenameData, &dwBytesRead, NULL);
	#else //unicode not defined
	WCHAR szTempBitmapName[MAX_PATH];
	ReadFile(hOpenFile, szTempBitmapName, sDataHeader.nSizeofBitmapFilenameData, &dwBytesRead, NULL);
	WideCharToMultiByte(CP_ACP, WC_NO_BEST_FIT_CHARS, szTempBitmapName, sDataHeader.nSizeofBitmapFilenameData/sizeof(WCHAR), m_lpstrBitmapFilename, MAX_PATH, NULL, NULL);
	#endif //unicode
	ReadFile(hOpenFile, m_pTileData, sDataHeader.nSizeofEntryData, &dwBytesRead, NULL);

	//With the data read lests open teh main bitmap
	if(FAILED(OpenBitmap2(m_lpstrBitmapFilename, 0))){
		CloseHandle(hOpenFile);
		return FALSE;
	}
	CloseHandle(hOpenFile);
	return TRUE;
}

HRESULT CEditTileLibrary::ImportLibrary(LPTSTR lpstrImportFilename){
	HRESULT hr=S_OK;

	HANDLE hFile;
	DWORD dwBytesRead;
	
	SLibraryHeader sLibraryHeader;
	SDataHeader2 sDataHeader2;
	
	BYTE *bitmapimage;

	if((hFile=CreateFile(lpstrImportFilename, GENERIC_READ, FILE_SHARE_READ, (LPSECURITY_ATTRIBUTES)NULL,
									OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, (HANDLE)NULL))==INVALID_HANDLE_VALUE)return E_FAIL;

	ReadFile(hFile, &sLibraryHeader, sizeof(SLibraryHeader), &dwBytesRead, NULL);
	if(sLibraryHeader.cType != *(WORD*)"IL"){CloseHandle(hFile); return E_FAIL;}
	if(sLibraryHeader.nVersion !=2){CloseHandle(hFile); return E_FAIL;}


	ReadFile(hFile, &sDataHeader2, sizeof(SDataHeader2), &dwBytesRead, NULL);

	ClearDataBase();	
	ReadFile(hFile, m_pTileData, sDataHeader2.nSizeofEntryData, &dwBytesRead, NULL);
	

	bitmapimage=new BYTE[sDataHeader2.lSizeofBitmapData];
	

	ReadFile(hFile, bitmapimage, sDataHeader2.lSizeofBitmapData, &dwBytesRead, NULL);

	CloseHandle(hFile);
	

	TCHAR BitmapName[MAX_PATH];


	_tcscpy(BitmapName, lpstrImportFilename);

	for(int i=0;i<(int)_tcslen(BitmapName);i++){
		if(BitmapName[i]=='.'){BitmapName[i]=NULL; break;}
	}
	
	_tcscat(BitmapName, TEXT(".bmp"));

	if((hFile=CreateFile(BitmapName, GENERIC_WRITE, FILE_SHARE_WRITE, (LPSECURITY_ATTRIBUTES)NULL,
										CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, (HANDLE)NULL))==INVALID_HANDLE_VALUE)return E_FAIL;

	DWORD dwBytesWritten;
	WriteFile(hFile, bitmapimage, sDataHeader2.lSizeofBitmapData, &dwBytesWritten, NULL);
	CloseHandle(hFile);
	SAFE_DELETE_ARRAY(bitmapimage);
	//_tcscpy(BitmapName, lpstrImportFilename);
	
	//Now that everythings all loaded lets prepare some infor and load
	//the bitmap
	CloseMainBitmap();
	m_nSelectedEntry=1;
	m_nNumEntries=sDataHeader2.nEntrys;
	OpenBitmap2(BitmapName, 0);

	return S_OK;
}

USHORT CEditTileLibrary::GetCurrentEntryData(STileData *pTileData){
	//(*pTileData).nBitmapReference = m_pTileData[m_nSelectedEntry-1].nBitmapReference;
	(*pTileData).nHeight = m_pTileData[m_nSelectedEntry-1].nHeight;
	(*pTileData).nWidth = m_pTileData[m_nSelectedEntry-1].nWidth;
	(*pTileData).nX = m_pTileData[m_nSelectedEntry-1].nX;
	(*pTileData).nY = m_pTileData[m_nSelectedEntry-1].nY;
	return 0;
}

HRESULT CEditTileLibrary::BuildLibrary(LPTSTR lpstrLibraryName){
	HRESULT hr=S_OK;
	HANDLE  hLibraryFile;
	HANDLE  hBitmapFile;

	//Lets start by preparing the headers
	SLibraryHeader LibraryHeader;
	SDataHeader2	DataHeader2;

	//Prepare file header
	LibraryHeader.cType=*(WORD*)"IL";
	LibraryHeader.nVersion		=2;
	LibraryHeader.lReserved1	=0;
	LibraryHeader.lReserved2	=0;
	LibraryHeader.nOffsetBits	=sizeof(DataHeader2);

	//Prepare the data header
	DataHeader2.nEntrys=GetNumEntries();
	DataHeader2.nSizeofEntryData=DataHeader2.nEntrys*sizeof(STileData);
	DataHeader2.lBitmapOffset=sizeof(SLibraryHeader)+sizeof(SDataHeader2)+DataHeader2.nSizeofEntryData;
	DataHeader2.lSizeofBitmapData=0;  //This value should change BITMAP

	
	//Lets get the bitmap information for writing
	DWORD dwBytesRead;
	BYTE *nBitmapBits;
	if((hBitmapFile=CreateFile(m_lpstrBitmapFilename, GENERIC_READ, FILE_SHARE_READ, (LPSECURITY_ATTRIBUTES)NULL,
								OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, (HANDLE)NULL))==INVALID_HANDLE_VALUE)return E_FAIL;
	if((DataHeader2.lSizeofBitmapData=GetFileSize(hBitmapFile, NULL))==NULL){
		//chances are the bitmap is too large;
		CloseHandle(hBitmapFile);
		return E_FAIL;
	}
	//allocate memory for bitmap image
	nBitmapBits=new BYTE[DataHeader2.lSizeofBitmapData];
	ReadFile(hBitmapFile, nBitmapBits, DataHeader2.lSizeofBitmapData, &dwBytesRead, NULL);
	CloseHandle(hBitmapFile);

	//now that we have the bitmap data lets start writing.
	DWORD dwBytesWritten;
	if((hLibraryFile=CreateFile(lpstrLibraryName, GENERIC_WRITE, FILE_SHARE_WRITE, (LPSECURITY_ATTRIBUTES)NULL,
								CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, (HANDLE)NULL))==INVALID_HANDLE_VALUE)return E_FAIL;

	//write data information
	WriteFile(hLibraryFile, &LibraryHeader, sizeof(SLibraryHeader), &dwBytesWritten, NULL);
	WriteFile(hLibraryFile, &DataHeader2, sizeof(SDataHeader2), &dwBytesWritten, NULL);
	WriteFile(hLibraryFile, m_pTileData, DataHeader2.nSizeofEntryData, &dwBytesWritten, NULL);
	WriteFile(hLibraryFile, nBitmapBits, DataHeader2.lSizeofBitmapData, &dwBytesWritten, NULL);

	SAFE_DELETE_ARRAY(nBitmapBits);
	CloseHandle(hLibraryFile);

	return hr;
}
