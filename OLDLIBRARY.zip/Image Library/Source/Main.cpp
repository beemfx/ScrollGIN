// image library.cpp : Defines the entry point for the application.
//
#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include "resource.h"
#include "edittilelibrary.h"

CEditTileLibrary g_cTileLibrary(256);
TCHAR			 g_sCurrentFilename[_MAX_PATH];

void TestDraw(HDC *hDc){
	HDC hdcMemSource, hdcMemTile;
	HBITMAP source, tile=NULL;

	source=(HBITMAP)LoadImage(NULL, TEXT("set1.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	hdcMemSource=hdcMemTile=CreateCompatibleDC(NULL);
	SelectObject(hdcMemSource, source);
	SelectObject(hdcMemTile, tile);
	StretchBlt(hdcMemTile, 0, 0, 40, 40, hdcMemSource, 0, 0, 40, 40, SRCCOPY);
	BitBlt(*hDc, 0, 0, 40, 40, hdcMemTile, 0, 0, SRCCOPY);
}



HRESULT MainWndPaint(HWND *hwnd){
	HDC hDc;
	
	PAINTSTRUCT ps;
	hDc=BeginPaint(*hwnd, &ps);
	g_cTileLibrary.DisplayImage(&hDc, 1, 0, 0, FALSE);
	g_cTileLibrary.DisplayImage(&hDc, 2, 0, 40, FALSE);
	g_cTileLibrary.DisplayImage(&hDc, 3, 0, 80, FALSE);
	g_cTileLibrary.DisplayImage(&hDc, 4, 0, 120, FALSE);
	g_cTileLibrary.DisplayImage(&hDc, 5, 0, 160, FALSE);
	g_cTileLibrary.DisplayImage(&hDc, 6, 0, 200, FALSE);
	g_cTileLibrary.DisplayImage(&hDc, 7, 40, 0, FALSE);
	g_cTileLibrary.DisplayImage(&hDc, 8, 40, 40, FALSE);
	//TestDraw(&hDc);

	EndPaint(*hwnd, &ps);
	return S_OK;
}

LRESULT MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam){
	switch(msg){
	case WM_CREATE:break;
	case WM_DESTROY:PostQuitMessage(0);break;
	case WM_PAINT:	MainWndPaint(&hwnd);break;
	default:return DefWindowProc(hwnd, msg, wParam, lParam);
	}
	return 0l;
}


HRESULT InitWindow(HWND *hwnd, HINSTANCE hInstance, LPTSTR name){
	WNDCLASSEX wndClass;

	wndClass.cbSize			= sizeof(wndClass);
	wndClass.cbClsExtra		= 0;
	wndClass.cbWndExtra		= 0;
	wndClass.hbrBackground	= (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndClass.hCursor			= LoadCursor(hInstance, IDC_ARROW);
	wndClass.hIcon				= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MAIN));
	wndClass.hIconSm			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MAIN));
	wndClass.hInstance		= hInstance;
	wndClass.lpfnWndProc		= (WNDPROC)MainWndProc;
	wndClass.lpszClassName	= name;
	wndClass.lpszMenuName	= MAKEINTRESOURCE(IDR_MENU1);
	wndClass.style				= CS_HREDRAW|CS_VREDRAW;
	
	if(!RegisterClassEx(&wndClass))return E_FAIL;

	*hwnd=CreateWindowEx(NULL, name, name,
								WS_MINIMIZEBOX|WS_CAPTION|WS_SYSMENU|WS_VSCROLL,
								CW_USEDEFAULT, CW_USEDEFAULT,
								160, 
								320, 
								NULL, 
								NULL, 
								hInstance,
								NULL);

	if(!*hwnd)return E_FAIL;
	return S_OK;
}

HRESULT UpdateDlg(HWND *hDlg){
	STileData tempTileData;
	g_cTileLibrary.GetCurrentEntryData(&tempTileData);
	
	TCHAR sTempString[100];
	
	SetDlgItemInt(*hDlg, IDC_ENTRYNUMBER, g_cTileLibrary.GetSelectedEntry(), FALSE);
	SetDlgItemInt(*hDlg, IDC_XEDIT, tempTileData.nX, FALSE);
	SetDlgItemInt(*hDlg, IDC_YEDIT, tempTileData.nY, FALSE);
	SetDlgItemInt(*hDlg, IDC_HEIGHTEDIT, tempTileData.nHeight, FALSE);
	SetDlgItemInt(*hDlg, IDC_WIDTHEDIT, tempTileData.nWidth, FALSE);

	g_cTileLibrary.GetBitmapName(sTempString);
	SetDlgItemText(*hDlg, IDC_BITMAPNAME, sTempString);
	SetDlgItemInt(*hDlg, IDC_NUMENTRIES, g_cTileLibrary.GetNumEntries(), FALSE);
	_stprintf(sTempString, TEXT("%s"), TEXT("IL"));
	SetDlgItemText(*hDlg, IDC_FILETYPE, sTempString);
	SetDlgItemInt(*hDlg, IDC_SIZEENTRYDATA, g_cTileLibrary.GetNumEntries()*sizeof(STileData), FALSE);
	SetDlgItemInt(*hDlg, IDC_SIZEFNAMEDATA, MAX_PATH*sizeof(TCHAR), FALSE);
	_stprintf(sTempString, TEXT("Libellus Ex Imago [%s]"), g_sCurrentFilename);
	SetWindowText(*hDlg, sTempString);
	
	//Lets paint the image
	//there is a problem here with the bitmap not always displaying
	HDC hDc;
	PAINTSTRUCT ps;

	hDc=GetDC(*hDlg);
	BeginPaint(*hDlg, &ps);

	RECT viewRect;
	POINT p;
	GetClientRect(GetDlgItem(*hDlg, IDC_IMAGEBOX), &viewRect);
	p.x=viewRect.left;
	p.y=viewRect.top;
	ClientToScreen(GetDlgItem(*hDlg, IDC_IMAGEBOX), &p);
	ScreenToClient(*hDlg, &p);

	g_cTileLibrary.DisplayImage(&hDc, g_cTileLibrary.GetSelectedEntry(), p.x, p.y, FALSE);

	EndPaint(*hDlg, &ps);

	ReleaseDC(*hDlg, hDc);
	return S_OK;
}

HRESULT ChangeEntryData(HWND *hDlg){
	int x, y, width, height;
	BOOL bSuccess;
	x=GetDlgItemInt(*hDlg, IDC_XEDIT, &bSuccess, TRUE);
	if(!bSuccess)return E_FAIL;
	y=GetDlgItemInt(*hDlg, IDC_YEDIT, &bSuccess, TRUE);
	if(!bSuccess)return E_FAIL;
	width=GetDlgItemInt(*hDlg, IDC_WIDTHEDIT, &bSuccess, TRUE);
	if(!bSuccess)return E_FAIL;
	height=GetDlgItemInt(*hDlg, IDC_HEIGHTEDIT, &bSuccess, TRUE);
	if(!bSuccess)return E_FAIL;

	g_cTileLibrary.CreateBitmapImage(g_cTileLibrary.GetSelectedEntry(), x, y, width, height);
	return S_OK;
}

HRESULT QueryForNewEntry(HWND *hDlg){
	if((MessageBox(*hDlg, TEXT("Add another entry?"),
					TEXT("Notice"), MB_YESNO|MB_ICONQUESTION))==IDNO)return S_FALSE;

	if((g_cTileLibrary.AddEntry(0, 0, 40, 40))==FALSE){
		MessageBox(*hDlg, TEXT("Could not create entry!\nOnly 255 entries are allowed."), TEXT("Warning"), MB_OK|MB_ICONWARNING);
		return E_FAIL;
	}
	MessageBox(*hDlg, TEXT("A new entry has been added with default values."), TEXT("Notice"), MB_OK|MB_ICONINFORMATION);
	g_cTileLibrary.SetSelectedEntry(g_cTileLibrary.GetNumEntries());
	return S_OK;
}

void UpdateSlider(HWND *hDlg, int position){
	HWND hSliderCtrl = GetDlgItem(*hDlg, IDC_IMAGESCROLL);
	SetScrollRange(hSliderCtrl, SB_CTL, 1, g_cTileLibrary.GetNumEntries(), TRUE);
	SetScrollPos(hSliderCtrl, SB_CTL, position, TRUE);
}

BOOL GetSaveFilename(LPTSTR title, LPTSTR strings, HWND hWnd, LPTSTR filename)
{
	OPENFILENAME ofn;

	ZeroMemory(&ofn, sizeof(OPENFILENAME));

	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hWnd;
	ofn.lpstrFilter = strings;//TEXT("Image Library Data (*.ilb)\0*.ilb\0All Files (*.*)\0*.*\0");
	ofn.lpstrFile = filename;
	ofn.nMaxFile = _MAX_PATH;
	ofn.lpstrTitle = title;//TEXT("Save Data As...");
	ofn.Flags = OFN_OVERWRITEPROMPT|OFN_HIDEREADONLY|OFN_NONETWORKBUTTON;

	return GetSaveFileName(&ofn);
}


BOOL GetOpenFilename(LPTSTR title, LPTSTR strings, HWND hWnd, LPTSTR filename)
{
	OPENFILENAME ofn;

	ZeroMemory(&ofn, sizeof(OPENFILENAME));

	ofn.lStructSize = sizeof( OPENFILENAME );
	ofn.hwndOwner = hWnd; // An invalid hWnd causes non-modality
	ofn.lpstrFilter = strings;//TEXT("Image Library Data (*.ilb)\0*.ilb\0All Files (*.*)\0*.*\0");
	ofn.lpstrFile = filename;  // Stores the result in this variable
	ofn.nMaxFile = _MAX_PATH;
	ofn.lpstrTitle = title;//TEXT("Open Data");  // Title for dialog
	ofn.Flags = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_PATHMUSTEXIST;
	//MessageBox(NULL, "made it here", "note", MB_OK);
	return GetOpenFileName(&ofn);
}

HRESULT NewDialogCommand(HWND *hwndDlg, WORD wNotifyCode, WORD wID, HWND hwndCtl){
	TCHAR sTempBitmapName[_MAX_PATH];
	HWND hCheckBox;
	switch(wID){
		case ID_CANCEL:
			EndDialog(*hwndDlg, 0);
			break;
		case ID_CREATE:
			GetDlgItemText(*hwndDlg, IDC_BITMAPTOUSE, sTempBitmapName, _MAX_PATH);
			if(FAILED(g_cTileLibrary.OpenBitmap2(sTempBitmapName, 0))){
				MessageBox(*hwndDlg, TEXT("Bitmap was not valid.  Try another file."), TEXT("Notice"), MB_OK|MB_ICONWARNING);
				break;
			}
			g_cTileLibrary.ClearDataBase();
			g_sCurrentFilename[0]=NULL;
			//Test to see if data should be auto determined
			hCheckBox=GetDlgItem(*hwndDlg, IDC_AUTOGENERATE);
			if(IsDlgButtonChecked(*hwndDlg, IDC_AUTOGENERATE)){
				g_cTileLibrary.AutoDetermineData();
			}else{
				g_cTileLibrary.AddEntry(0, 0, 40, 40);
			}
			EndDialog(*hwndDlg, 1);
			break;
		case ID_BROWSE:
			_tcscpy(sTempBitmapName, TEXT("bitmap image"));
			GetOpenFilename(TEXT("Select Bitmap Image"), TEXT("Bitmap Image (*.bmp)\0*.bmp\0All Files (*.*)\0*.*\0"), *hwndDlg, sTempBitmapName);
			SetDlgItemText(*hwndDlg, IDC_BITMAPTOUSE, sTempBitmapName);
			break;
		default:break;
	}
	return S_OK;
}

BOOL CALLBACK NewDialogProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam){
	switch(msg){
		case WM_INITDIALOG:
			CheckDlgButton(hwndDlg, IDC_AUTOGENERATE, BST_CHECKED);
			break;
		case WM_COMMAND:
			NewDialogCommand(&hwndDlg, HIWORD(wParam), LOWORD(wParam), (HWND)lParam);
			break;
		default:return FALSE;
	}
	return TRUE;
}

BOOL GenerateNewLibrary(HWND hwndOwner){
	DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_NEWDIALOG), hwndOwner, DLGPROC(NewDialogProc));
	UpdateDlg(&hwndOwner);
	return TRUE;
}

//This function appends a file extens if there isn't one.
BOOL AppendExtension(TCHAR dest[MAX_PATH], LPTSTR extension){
	BOOL bIsExtension=FALSE;
	for(int i=0;i<(int)_tcslen(dest);i++){
		if(dest[i]=='.'){
		bIsExtension=TRUE; 
		break;}
	}
	
	if(!bIsExtension)_tcscat(dest, extension);
	return TRUE;
}

BOOL GetRegValues(TCHAR filename[MAX_PATH]){
	HKEY hKey;
	DWORD dwDisp;
	//if((RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("Software\\Beem\\Image Library"), 0, KEY_ALL_ACCESS, &hKey))!=ERROR_SUCCESS){
	if((RegCreateKeyEx(HKEY_LOCAL_MACHINE, TEXT("Software\\Beem\\Image Library"), 0, NULL, 0, KEY_ALL_ACCESS, NULL, &hKey, &dwDisp))!=ERROR_SUCCESS){
		return FALSE;
	}
	DWORD dwSize=MAX_PATH;
	if((RegQueryValueEx(hKey, TEXT("Lastfile"), NULL, NULL, (BYTE*)filename, &dwSize))!=ERROR_SUCCESS){
		RegCloseKey(hKey);
		return FALSE;
	}
	//MessageBox(NULL, "Made it here", "Made it here", MB_OK);
	RegCloseKey(hKey);
	return TRUE;
}

BOOL SaveRegValues(LPTSTR filename){
	HKEY hKey;
	DWORD dwDisp;
	//if((RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("Software\\Beem\\Image Library"), 0, KEY_WRITE, &hKey))!=ERROR_SUCCESS){
	if((RegCreateKeyEx(HKEY_LOCAL_MACHINE, TEXT("Software\\Beem\\Image Library"), 0, NULL, 0, KEY_WRITE, NULL, &hKey, &dwDisp))!=ERROR_SUCCESS){
		return FALSE;
	}
	DWORD dwSize=_tcslen(filename)*sizeof(TCHAR);
	RegSetValueEx(hKey, TEXT("Lastfile"), NULL, REG_SZ, (BYTE*)filename, dwSize);
	RegCloseKey(hKey);
	return TRUE;
}

HRESULT DialogCommand(HWND *hwndDlg, WORD wNotifyCode, WORD wID, HWND hwndCtl){
	TCHAR tempfilename[_MAX_PATH];
	
	switch(wID){
		case ID_LIBRARY_IMPORT:
			_tcscpy(tempfilename, TEXT("Import Library"));
			if(GetOpenFilename(TEXT("Affaman Libellus..."), TEXT("Image Library File (*.ilf)\0*.ilf\0All Files (*.*)\0*.*\0"), *hwndDlg, tempfilename)){
				if(SUCCEEDED(g_cTileLibrary.ImportLibrary(tempfilename))){
					MessageBox(*hwndDlg, TEXT("Successfully Imported Library"), TEXT("Notice"), MB_OK|MB_ICONINFORMATION);
					g_sCurrentFilename[0]=NULL;
				}else MessageBox(*hwndDlg, TEXT("Import Failed"), TEXT("Warning"), MB_OK|MB_ICONWARNING);
			}
			UpdateSlider(hwndDlg, 1);
			UpdateDlg(hwndDlg);
			break;
		case ID_BUILD_MAKELIBRARY:
			_tcscpy(tempfilename, TEXT("Library File"));
			if(GetSaveFilename(TEXT("Condo Libellus..."), TEXT("Image Library File (*.ilf)\0*.ilf\0All Files (*.*)\0*.*\0"), *hwndDlg, tempfilename)){
				AppendExtension(tempfilename, TEXT(".ilf"));
				if(SUCCEEDED(g_cTileLibrary.BuildLibrary(tempfilename))){
					MessageBox(*hwndDlg, TEXT("Library Successfully Built"), TEXT("Notice"), MB_OK|MB_ICONINFORMATION);
				}else MessageBox(*hwndDlg, TEXT("Failed To Build Library"), TEXT("Warning"), MB_OK|MB_ICONWARNING);
				//should make sure file has appropriate extension here
			}
			break;
		case ID_FILE_EXIT:DestroyWindow(*hwndDlg);break;
		case ID_CLOSE:DestroyWindow(*hwndDlg);break;
		case ID_FILENEW:
			GenerateNewLibrary(*hwndDlg);
			UpdateSlider(hwndDlg, 1);
			UpdateDlg(hwndDlg);
			break;
		case ID_FILESAVEAS:
			_tcscpy(tempfilename, g_sCurrentFilename);
			if(GetSaveFilename(TEXT("Servo Indicium..."), TEXT("Image Library Data (*.ild)\0*.ild\0All Files (*.*)\0*.*\0"), *hwndDlg, tempfilename)){
				AppendExtension(tempfilename, TEXT(".ild"));
				_tcscpy(g_sCurrentFilename, tempfilename);
				g_cTileLibrary.SaveData(tempfilename);
				//should make sure file has appropriate extension here
			}
			if(g_sCurrentFilename[0]==NULL)break;//filename does not exist so break
			//fall through and save
		case ID_FILESAVE:
			if(g_sCurrentFilename[0]==NULL){
				WPARAM wParam=NULL;
				LPARAM lParam=NULL;
				wParam=ID_FILESAVEAS;
				SendMessage(*hwndDlg, WM_COMMAND, wParam, lParam);
				break;
			}
			g_cTileLibrary.SaveData(g_sCurrentFilename);
			SaveRegValues(g_sCurrentFilename);
			UpdateDlg(hwndDlg);
			break;
		case ID_FILEOPEN:
			_tcscpy(tempfilename, g_sCurrentFilename);
			if(GetOpenFilename(TEXT("Expositus Indicium..."), TEXT("Image Library Data (*.ild)\0*.ild\0All Files (*.*)\0*.*\0"), *hwndDlg, tempfilename)){
				_tcscpy(g_sCurrentFilename, tempfilename);
				g_cTileLibrary.LoadData(tempfilename);
				UpdateSlider(hwndDlg, 1);
			}
			SaveRegValues(g_sCurrentFilename);
			UpdateDlg(hwndDlg);
			break;
		case ID_ADDENTRY:
			QueryForNewEntry(hwndDlg);
			UpdateSlider(hwndDlg, g_cTileLibrary.GetNumEntries());
			UpdateDlg(hwndDlg);
			break;
		/*
		case ID_NEXT:
			if(g_cTileLibrary.GetSelectedEntry()==g_cTileLibrary.GetNumEntries()){
				QueryForNewEntry(hwndDlg);
			}
			g_cTileLibrary.SetSelectedEntry(g_cTileLibrary.GetSelectedEntry()+1);
			UpdateDlg(hwndDlg);
			break;
		case ID_PREV:
			g_cTileLibrary.SetSelectedEntry(g_cTileLibrary.GetSelectedEntry()-1);
			UpdateDlg(hwndDlg);
			break;
		*/
		case ID_APPLY:
			ChangeEntryData(hwndDlg);
			UpdateDlg(hwndDlg);
			break;
		default:break;
		case ID_HELPABOUT:
			#ifdef UNICODE
			MessageBox(*hwndDlg, TEXT("Image Library version 1.00 UNICODE\n   TileLibrary Version 1.00"), TEXT("About Image Library"), MB_OK|MB_ICONINFORMATION);
			#else //unicode
			MessageBox(*hwndDlg, TEXT("Image Library version 1.00 ANSI\n   TileLibrary Version 1.00"), TEXT("About Image Library"), MB_OK|MB_ICONINFORMATION);
			#endif //ansi
			break;
	}
	return S_OK;
}

BOOL CALLBACK MainDlgProc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam){
	//static HBITMAP hLeftArrow=(HBITMAP)LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_LEFTARROW), IMAGE_BITMAP, 0, 0, NULL);
	//static HBITMAP hRightArrow=(HBITMAP)LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_RIGHTARROW), IMAGE_BITMAP, 0, 0, NULL);
	
	switch(msg){
		case WM_INITDIALOG:
			//SendDlgItemMessage(hwndDlg, ID_PREV, BM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hLeftArrow);
			//SendDlgItemMessage(hwndDlg, ID_NEXT, BM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hRightArrow);
			
			/*
			SCROLLINFO scrollInfo;
			HWND hSliderCtrl;
			hSliderCtrl = GetDlgItem(hwndDlg, IDC_IMAGESCROLL);
			scrollInfo.cbSize=sizeof(scrollInfo);
			scrollInfo.nMin=1;
			scrollInfo.nMax=1;
			scrollInfo.fMask=SIF_RANGE;
			SetScrollInfo(hSliderCtrl, SB_CTL, &scrollInfo, TRUE);
			*/
			UpdateDlg(&hwndDlg);
			break;
		case WM_PAINT:	
			UpdateDlg(&hwndDlg);
			break;
		case WM_COMMAND:
			DialogCommand(&hwndDlg, HIWORD(wParam), LOWORD(wParam), (HWND)lParam);
			//UpdateDlg(&hwndDlg);
			break;
		case WM_HSCROLL:{
			HWND hCtrl=(HWND)lParam;
			//SCROLLINFO sInfo;
			//GetScrollInfo(hCtrl, SB_CTL, &sInfo);
			//sInfo.nMin=1;
			//sInfo.nMax=g_cTileLibrary.GetNumEntries();
			static int nPos;
			//SetScrollInfo(hCtrl, SB_CTL, &sInfo, TRUE);
			SetScrollRange(hCtrl, SB_CTL, 1, g_cTileLibrary.GetNumEntries(), TRUE);
			switch(LOWORD(wParam)){
				case SB_LINEDOWN:
				case SB_PAGEDOWN:
					if(nPos==g_cTileLibrary.GetNumEntries())break;
					g_cTileLibrary.SetSelectedEntry(g_cTileLibrary.GetSelectedEntry()+1);
					nPos=g_cTileLibrary.GetSelectedEntry();
					break;
				case SB_PAGEUP:
				case SB_LINEUP:
					if(nPos==1)break;
					g_cTileLibrary.SetSelectedEntry(g_cTileLibrary.GetSelectedEntry()-1);
					nPos=g_cTileLibrary.GetSelectedEntry();
					break;
				case SB_TOP:
					g_cTileLibrary.SetSelectedEntry(1);
					nPos=g_cTileLibrary.GetSelectedEntry();
					break;
				case SB_BOTTOM:
					g_cTileLibrary.SetSelectedEntry(g_cTileLibrary.GetNumEntries());
					nPos=g_cTileLibrary.GetSelectedEntry();
					break;
				case SB_THUMBTRACK:
				case SB_THUMBPOSITION:
					g_cTileLibrary.SetSelectedEntry(HIWORD(wParam));
					nPos=g_cTileLibrary.GetSelectedEntry();
					break;
			}
			SetScrollPos(hCtrl, SB_CTL, nPos, TRUE);
			UpdateDlg(&hwndDlg);
			}break;
		case WM_DESTROY:
			//DeleteObject(hLeftArrow);
			//DeleteObject(hRightArrow);
			PostQuitMessage(0);
			break;
		case WM_CLOSE:DestroyWindow(hwndDlg);break;
		default:return FALSE;
	}
	return TRUE;
}


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	HWND hwndMain;
	MSG msg;
	HACCEL hAccel;


	#define DLGMODE

	//DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, DLGPROC(MainDlgProc));

	#ifdef DLGMODE
	hwndMain=CreateDialog(hInstance, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, DLGPROC(MainDlgProc));
	#else
	if(FAILED(InitWindow(&hwndMain, hInstance, TEXT("Libellus Ex Imago"))))return 0;
	#endif //DLGMODE
	
	GetRegValues(g_sCurrentFilename);
	//MessageBox(NULL, g_sCurrentFilename, TEXT("Notice"), MB_OK);
	if(!g_cTileLibrary.LoadData(g_sCurrentFilename)){
	int mbResult;
	mbResult=MessageBox(NULL, TEXT("Unable to load last used file.\nOpen Existing File?"), TEXT("Libellus Ex Imago"), MB_ICONINFORMATION|MB_YESNOCANCEL);
		if(mbResult==IDYES){
			WPARAM wParam;
			wParam=ID_FILEOPEN;
			SendMessage(hwndMain, WM_COMMAND, wParam, NULL);
		}else if(mbResult==IDNO)GenerateNewLibrary(hwndMain);
		else return 0;
	}

	ShowWindow(hwndMain, nCmdShow);
	UpdateWindow(hwndMain);

	hAccel=LoadAccelerators(hInstance, MAKEINTRESOURCE(IDR_ACCELERATOR1));
	//DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, DLGPROC(MainWndProc));

	while(TRUE){
		if(!GetMessage(&msg, NULL, 0, 0)){
			return msg.wParam;
		}
		if(!TranslateAccelerator(msg.hwnd, hAccel, &msg)){
			TranslateMessage(&msg); DispatchMessage(&msg);
		}
	}
}