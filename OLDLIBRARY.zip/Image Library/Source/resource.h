//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDI_MAIN                        101
#define IDR_MENU1                       102
#define IDR_ACCELERATOR1                103
#define DUMMY_BITMAP                    104
#define IDD_MAINDIALOG                  105
#define IDB_LEFTARROW                   106
#define IDB_RIGHTARROW                  107
#define IDD_NEWDIALOG                   108
#define ID_APPLY                        1000
#define ID_CLOSE                        1001
#define IDC_IMAGEBOX                    1002
#define IDC_XEDIT                       1006
#define IDC_YEDIT                       1007
#define IDC_WIDTHEDIT                   1008
#define IDC_HEIGHTEDIT                  1009
#define IDC_ENTRYNUMBER                 1010
#define IDC_FILETYPE                    1012
#define IDC_FILEVERSION                 1013
#define IDC_NUMENTRIES                  1015
#define IDC_SIZEENTRYDATA               1016
#define IDC_SIZEFNAMEDATA               1017
#define IDC_SIZEBITMAPDATA              1018
#define IDC_EDIT1                       1019
#define IDC_BITMAPTOUSE                 1019
#define IDC_BROWSE                      1021
#define ID_BROWSE                       1021
#define ID_CREATE                       1022
#define ID_CANCEL                       1023
#define IDC_AUTOGENERATE                1024
#define IDC_IMAGESCROLL                 1027
#define ID_ADDENTRY                     1028
#define IDC_BITMAPNAME                  1029
#define ID_FILE_SAVEAS                  40004
#define ID_FILESAVEAS                   40004
#define ID_FILE_EXIT                    40005
#define ID_LIBRARY_IMPORT               40006
#define ID_LIBRARY_ADDIMAGE             40007
#define ID_BUILD_MAKELIBRARY            40008
#define ID_FILESAVE                     40010
#define ID_FILEOPEN                     40011
#define ID_FILENEW                      40012
#define ID_HELPABOUT                    40013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
