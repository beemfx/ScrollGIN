#ifndef __EDITTILELIBRARY_H__
#define __EDITTILELIBRARY_H__

#include "TileLibrary.h"

class CEditTileLibrary: public CTileLibrary{
private:
	USHORT	m_nMaxEntries;
public:
	CEditTileLibrary(int maxtiles);
	~CEditTileLibrary();

	void GetBitmapName(LPTSTR dest);
	BOOL AddEntry(int x, int y, int width, int height);
	HRESULT AutoDetermineData();
	HRESULT BuildLibrary(LPTSTR lpstrLibraryName);
	//Here are some functions for manipulating data
	USHORT GetCurrentEntryData(STileData *pTileData);
	HRESULT ImportLibrary(LPTSTR lpstrImportFilename);
	BOOL SaveData(LPTSTR SaveFilename);
	BOOL LoadData(LPTSTR LoadFilename);
	BOOL CreateBitmapImage(int reference, int x, int y, int width, int height);
};


#endif //__edittilelibrary_h__