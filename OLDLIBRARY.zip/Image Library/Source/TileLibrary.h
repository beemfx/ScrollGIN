#ifndef __TILELIBRARY_H__
#define __TILELIBRARY_H__

#include <windows.h>
#include <tchar.h>
#include "defines.h"
#include "resource.h"

#define TILEDIMENSION 40

typedef struct STileData{
	USHORT nX;
	USHORT nY;
	USHORT nWidth;
	USHORT nHeight;
}TILEDATA;

struct SLibraryHeader{
	WORD		cType;		//The type of file "IL"
	USHORT	nVersion;		//1 for database 2 for library build
	ULONG		lReserved1;
	ULONG		lReserved2;
	USHORT	nOffsetBits;	//how many bits offset for the data Header
};

struct SDataHeader{
	USHORT nEntries;
	USHORT nSizeofBitmapFilenameData;
	USHORT nSizeofEntryData;
};

//Data Header 2 is for the build command
struct SDataHeader2{
	USHORT	nEntrys;					//how many entrys
	USHORT	nSizeofEntryData;		//how many bytes entry takes
	DWORD		lSizeofBitmapData;	//how many bytes bitmap takes
	ULONG		lBitmapOffset;		//How many bytes the bitmap is offset from start of the file
};

class CTileLibrary{
protected:
	TCHAR			m_lpstrBitmapFilename[_MAX_PATH];
	USHORT		m_nSelectedEntry;
	USHORT		m_nNumEntries;

	STileData	*m_pTileData;
	HBITMAP		m_hMainBitmap;
	
public:
	CTileLibrary();
	~CTileLibrary();
	USHORT GetNumEntries();
	void SetSelectedEntry(int newentryvalue);
	USHORT GetSelectedEntry();
	HRESULT OpenBitmap(LPTSTR BitmapFilename);
	HRESULT OpenBitmap2(LPTSTR BitmapFilename, DWORD OffsetBytes);
	void CloseMainBitmap();
	HRESULT ClearDataBase();
	HRESULT DisplayImage(HDC *hDc, int reference, int x, int y, BOOL bTransp);
};

#endif //__tilelibrary_h__